package pack;

public class Location {
	public double X;
	public double Y;

}