package pack;

public class Help {

	String helpTextMsg = "Warning: The level of CO2 is high in this area. It’s more than 0.6%";
	
}
