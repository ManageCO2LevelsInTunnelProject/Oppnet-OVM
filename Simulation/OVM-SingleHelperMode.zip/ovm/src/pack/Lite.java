package pack;

public class Lite extends Helper{

	public Lite(String name, Parameters p, double msgPayloadReadTime) {
		super(name, p, msgPayloadReadTime);
		this.msgPayloadReadtime = msgPayloadReadTime;
	}

}
