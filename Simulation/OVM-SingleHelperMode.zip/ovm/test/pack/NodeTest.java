/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import eduni.simjava.Sim_event;
import eduni.simjava.Sim_entity;
import eduni.simjava.Sim_system;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import eduni.simjava.*;
import static org.junit.Assert.*;

/**
 *
 * @author hessah
 */
public class NodeTest  {
    
    public NodeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of NODE_addNode method, of class Node.
     */
    @Test
 
    public void testNODE_addNode() {
        System.out.println("NODE_addNode");
        Sim_system.initialise();
        ArrayList<Node> oppnet = new  ArrayList<Node>();
        Parameters p = new Parameters();
        Regular_Helper myHelper  = new Regular_Helper("Car",p,0);
        ArrayList<Node> expResult_MyOpp = new  ArrayList<Node>();
        expResult_MyOpp.add(myHelper);
        ArrayList<Node> result = myHelper.NODE_addNode(oppnet, myHelper);
        assertEquals(expResult_MyOpp, result);

    }

    /**
     * Test of NODE_discover method, of class Node.
     */
   @Test
  
    public void testNODE_discover() {
        System.out.println("NODE_discover");
        Sim_system.initialise();
        Parameters p = new Parameters();
        Lite myHelper = new Lite("Billboard",p,p.msgPayloadReadTimeLite);
	myHelper.OPP = true;
	myHelper.Coordinator = true; 
        boolean expResult = true;
        boolean result = myHelper.NODE_discover(myHelper);
        assertEquals(expResult, result); }

    /**
     * Test of NODE_evalAdmit method, of class Node.
     */
 /*  @Test
    public void testNODE_evalAdmit() {
           Sim_system.initialise();
        System.out.println("NODE_evalAdmit");
       
        
         Parameters p = new Parameters();
       // Sim_entity e=new Sim_entity("Test");
        // Sim_entity e1=new Sim_entity("Test2");
         Regular_Helper h = new Regular_Helper("Fan", p, 0);
      Lite h2 = new Lite("Car", p, 0);
       
        Sim_event ev = new Sim_event();
        h.sim_wait_for(2, ev);
       Sim_system.run_start();


   h.sim_schedule(h2.get_id(), 0.5, 15, "Join");    
              
       //h2.NODE_reqHelp(h);
      
         Sim_system.run_tick();
   
               h2.sim_get_next(ev);  
    
       
       System.out.println(Sim_system.running());

        
       
      /*  Parameters p = new Parameters();
          Lite myHelper  = new Lite("Car", p, 0);
         Lite myHelper2  = new Lite("Fan", p, 0);
        //  Sim_system.run_start();
       // Sim_system.run_tick();
          myHelper.sim_schedule(myHelper2.get_id(), myHelper2.ctrlMsgDelTimeThroughLinkToParent, 23, "Join");
          Sim_event ev = new Sim_event();
          // Sim_system.run_tick();
          ev = myHelper2.NODE_listen();
         boolean expResult=false;
         boolean result=false;
         System.out.println(Sim_system.running());*/
         
       
        /* boolean result =h2.NODE_evalAdmit(ev, h);
          boolean expResult = true;
         Sim_system.run_stop();
       
        assertEquals("no corre",expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }*/

    /**
     * Test of NODE_initiate method, of class Node.
     */
    @Test
    public void testNODE_initiate() {
        System.out.println("NODE_initiate");
         Parameters p = new Parameters();
         ArrayList<Node> oppnet = new  ArrayList<Node>();
        Seed s = new Seed("Sensor",p,p.msgPayloadReadTimeSeed);
        oppnet.add(s);
        Node instance = new Node("Test", p.msgPayloadReadTimeSeed);
        Parameters expResult = s.pr;
        Parameters result = instance.NODE_initiate(s);
        assertEquals(expResult, result);     
    }
    
      @Test
    public void testNODE_scan() {
        System.out.println("NODE_scan");
        Sim_system.initialise();
           Parameters prm = new Parameters();
       Lite nd  = new Lite("Car", prm,  prm.approxMsgPayloadReadTimeRegHlpr);
					nd.device = "Car";
					nd.sortingOrder = 2;
					nd.category = "Adhoc";
					nd.OPP = true;
                                       nd.Comm_Channels.add("BT");
					nd.Comm_Channels.add("Zigbee");
                                        nd.Comm_Channels.add("Wi-Fi");
					nd.DeviceApps.add("Display");
					nd.Coordinator = true;
        ArrayList<Helper> expResult = new ArrayList<Helper>();
       double dist=100;
	  Helper cand;
      Location distance = new Location();
      for (int c = 0; c < prm.Helpers.size(); c++) {
			distance.X = Math.abs(prm.Helpers.get(c).location.X - nd.location.X);
			distance.Y = Math.abs(prm.Helpers.get(c).location.Y - nd.location.Y);
			distance.X = Math.floor(distance.X * 100) / 100;
			distance.Y = Math.floor(distance.Y * 100) / 100;
			boolean match = false;
			for (int x = 0; x < nd.Comm_Channels.size(); x++) {
				for (int k = 0; k < prm.Helpers.get(c).Comm_Channels.size(); k++) {
					if (nd.Comm_Channels.get(x).equals(prm.Helpers.get(c).Comm_Channels.get(k))
							&& distance.X <= dist
							&& distance.Y <= dist
							&& !(prm.oppnet.contains(prm.Helpers.get(c)))) { 
						match = true;
						if (nd.Comm_Channels.get(x).equals("BT")) {
							prm.Helpers.get(c).linkWithParent = "BT";
							prm.Helpers.get(c).ctrlMsgDelTimeThroughLinkToParent = prm.actualBTdelTimeCtrlMsg;
							nd.task2Runtime = nd.msgPayloadReadtime
									+ prm.actualBTdelTimeHelpObjectMsg;
							nd.task3Runtime = nd.msgPayloadReadtime
									+ prm.actualBTdelTimeOppnetTaskMsg;
						} else if (nd.Comm_Channels.get(x).equals(
								"Zigbee")) {
							prm.Helpers.get(c).linkWithParent = "Zigbee";
							prm.Helpers.get(c).ctrlMsgDelTimeThroughLinkToParent = prm.actualZigBeeDelTimeCtrlMsg;
							nd.task2Runtime = nd.msgPayloadReadtime
									+ prm.actualZigBeeDelTimeHelpObjectMsg ;
							nd.task3Runtime = nd.msgPayloadReadtime
									+ prm.actualZigBeeDelTimeOppnetTaskMsg;
						} else if (nd.Comm_Channels.get(x).equals(
								"WiFi")) {
							prm.Helpers.get(c).linkWithParent = "WiFi";
							prm.Helpers.get(c).ctrlMsgDelTimeThroughLinkToParent = prm.actualWiFiDelTimeCtrlMsg;
							nd.task2Runtime = nd.msgPayloadReadtime
									+ prm.actualWiFiDelTimeHelpObjectMsg;
							nd.task3Runtime = nd.msgPayloadReadtime
									+ prm.actualWiFiDelTimeOppnetTaskMsg;}
						expResult.add(prm.Helpers.get(c));
						break;}}
         if (match) break;  }  } 
        ArrayList<Helper> result = nd.NODE_scan(nd, prm, dist);
        assertEquals(expResult, result);   }

    /**
     * Test of NODE_isMember method, of class Node.
     */
    @Test
public void testNODE_isMember() {
        System.out.println("NODE_isMember");
        ArrayList<Node> oppnet = new ArrayList<Node>();
        Parameters p = new Parameters();
        Lite myHelper = new Lite("Billboard",p,p.msgPayloadReadTimeLite);
        oppnet.add(myHelper);
        boolean expResult = true;
        boolean result = myHelper.NODE_isMember(oppnet, myHelper);
        assertEquals(expResult, result);
}

    /**
     * Test of NODE_joinOppnet method, of class Node.
     */
   @Test
   
    public void testNODE_joinOppnet() {
        System.out.println("NODE_joinOppnet");
        Parameters p = new Parameters();
        String category = "Adhoc";
        double workloadRatio = 20;
        Lite invitingNode = new Lite("Billboard",p,p.msgPayloadReadTimeLite);
        invitingNode.category = "Adhoc";
        double deliveryTime = 0.287; //BT
        boolean expResult = true;
        boolean result = invitingNode.NODE_joinOppnet(category, workloadRatio, invitingNode, deliveryTime);
        assertEquals(expResult, result);
    }

    /**
     * Test of NODE_listen method, of class Node.
     */
  /*  @Test
    public void testNODE_listen_0args() {
        System.out.println("NODE_listen");
        Node instance = null;
        Sim_event expResult = null;
        Sim_event result = instance.NODE_listen();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of NODE_listen method, of class Node.
     */
   /* @Test
    public void testNODE_listen_3args() {
        System.out.println("NODE_listen");
        String msg = "";
        String name = "";
        int id = 0;
        Node instance = null;
        boolean expResult = false;
        boolean result = instance.NODE_listen(msg, name, id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of NODE_processMsg method, of class Node.
     */
    /*@Test
    public void testNODE_processMsg() {
        System.out.println("NODE_processMsg");
        double msgReadTime = 0.0;
        Node instance = null;
        instance.NODE_processMsg(msgReadTime);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of NODE_release method, of class Node.
     */
  /*  @Test
    public void testNODE_release() {
        System.out.println("NODE_release");
       
	Sim_system.initialise();	
         
        Parameters p = new Parameters();
         Sim_entity e=new Sim_entity("Test");
          Sim_entity e1=new Sim_entity("Test2");
         Lite h = new Lite("Car", p, 0);
      
                                      
      Sim_system.run_start();
 Sim_event ev = new Sim_event();
   e1.sim_schedule(e.get_id(), 0.5, 15, "ReqHelp");    
  
       Sim_system.run_tick();
    
               e.sim_get_next(ev);  
    
       System.out.println(Sim_system.running());
        boolean expResult = true;     
        boolean result = h.NODE_validate(ev);
        Sim_system.run_stop();
       
        assertEquals("not correct",expResult, result);
    }

    /**
     * Test of NODE_remNode method, of class Node.
     */
    @Test
   
    public void testNODE_remNode() {
        System.out.println("NODE_remNode");
       ArrayList<Node> oppnet = new ArrayList<Node>();
        Parameters p = new Parameters();
        Lite myHelper = new Lite("Billboard",p,p.msgPayloadReadTimeLite);
        oppnet.add(myHelper);
        ArrayList<Node> myoppnet = new ArrayList<Node>();
        myoppnet.add(myHelper);
        myoppnet.remove(myHelper);
        ArrayList<Node> result = myHelper.NODE_remNode(myHelper, oppnet);
        assertEquals(myoppnet, result);

    }

    /**
     * Test of NODE_report method, of class Node.
     */
   /* @Test
    public void testNODE_report() {
        System.out.println("NODE_report");
        Helper candidateHelper = null;
        double task2Runtime = 0.0;
        int tag = 0;
        Help helpObject = null;
        Node instance = null;
        instance.NODE_report(candidateHelper, task2Runtime, tag, helpObject);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of NODE_reqHelp method, of class Node.
     */
   /* @Test
    public void testNODE_reqHelp() {
        System.out.println("NODE_reqHelp");
        Helper Candidate_Helper = null;
        Node instance = null;
        instance.NODE_reqHelp(Candidate_Helper);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of NODE_reqRelease method, of class Node.
     */
   /* @Test
    public void testNODE_reqRelease() {
        System.out.println("NODE_reqRelease");
        int id = 0;
        String name = "";
        Node invitingNode = null;
        double deliveryTime = 0.0;
        String msg = "";
        Node instance = null;
        boolean expResult = false;
        boolean result = instance.NODE_reqRelease(id, name, invitingNode, deliveryTime, msg);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of NODE_runApp method, of class Node.
     */
   @Test
 
    public void testNODE_runApp() {
        System.out.println("NODE_runApp");
        Parameters p = new Parameters();
        Lite h = new Lite("Fan",p,p.msgPayloadReadTimeLite);
        h.device = "Fan";
        String DeviceTask = "Goal Urgent Circulate fresh air";
        Help helpObject = new Help();
        boolean expResult = true;
        boolean result = h.NODE_runApp(h, DeviceTask, helpObject, p);
        assertEquals(expResult, result);
    }
    

    /**
     * Test of NODE_scan method, of class Node.
     */ /*


    /**
     * Test of NODE_selectTask method, of class Node.
     */
   @Test
    public void testNODE_selectTask() {
         Sim_system.initialise();
        System.out.println("NODE_selectTask");
         Parameters p = new Parameters();
       Lite h  = new Lite("Car", p, 0);
        h.device = "Car";
                                       h.sortingOrder = 2;
                                       h.category = "Adhoc";
                                       h.Comm_Channels.add("BT");
                                       h.OPP = true;
                                       h.Comm_Channels.add("Zigbee");
                                       h.Coordinator = true; 
                                       h.DeviceApps.add("Display");
                                      
        ArrayList<String> oppnetTasks = new ArrayList<String>();
     oppnetTasks.add("Unhurried Display help msg");

       Help helpObject=new Help();
        boolean expResult = false;
        boolean result = h.NODE_selectTask(h, h.DeviceApps, oppnetTasks, helpObject, p);
        assertEquals(expResult, result);}

    /**
     * Test of NODE_sendData method, of class Node.
     */
   /* @Test
    public void testNODE_sendData() {
        System.out.println("NODE_sendData");
        Helper candidateHelper = null;
        double task3Runtime = 0.0;
        int tag = 0;
        ArrayList<String> oppnetTasks = null;
        Node instance = null;
        instance.NODE_sendData(candidateHelper, task3Runtime, tag, oppnetTasks);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of NODE_terminate method, of class Node.
     */
    @Test
    public void testNODE_terminate() {
        System.out.println("NODE_terminate");
         Parameters p = new Parameters();
        ArrayList<Node> oppnet = new ArrayList<Node>();
        ArrayList<Node> oppnet1 = new ArrayList<Node>();
        Lite h = new Lite("Car", p, 0);
          Lite h2  = new Lite("Car", p, 0);
          Seed h3  = new Seed("Sensor", p, 0);
          oppnet.add(h3);
          oppnet1.add(h3);
          oppnet.add(h);
          oppnet1.add(h2);
          oppnet.clear();

        h3.NODE_terminate(oppnet1, h3.get_id(), h3.getName());
        assertEquals(oppnet.size(), oppnet1.size());
        
    }

    /**
     * Test of NODE_validate method, of class Node.
     */
    @Test
    public void testNODE_validate() {
	Sim_system.initialise();	
         
        System.out.println("NODE_validate");
        Parameters p = new Parameters();
         Sim_entity e=new Sim_entity("Test");
          Sim_entity e1=new Sim_entity("Test2");
         Lite h = new Lite("Car", p, 0);                               
      Sim_system.run_start();
 Sim_event ev = new Sim_event();
   e1.sim_schedule(e.get_id(), 0.5, 15, "ReqHelp");    
       Sim_system.run_tick();
               e.sim_get_next(ev);  
       System.out.println(Sim_system.running());
        boolean expResult = true;     
        boolean result = h.NODE_validate(ev);
        Sim_system.run_stop();
       
        assertEquals(expResult, result);    }}
