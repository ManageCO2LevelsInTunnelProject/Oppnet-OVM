/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;


import java.util.Hashtable;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.util.mxConstants;
import com.mxgraph.view.mxGraph;
import com.mxgraph.view.mxStylesheet;
import java.util.ArrayList;

/**
 *
 * @author hessah
 */
public class graph extends JFrame {
   public static  ArrayList <String> nodeNames = new ArrayList<String>();
   public static  ArrayList <Location> nodeLoc = new ArrayList<Location>(); 

public static ArrayList<Object> vertex= new ArrayList<Object>();
public static  ArrayList <String> comm = new ArrayList<String>();
public static  ArrayList <Double> integ = new ArrayList<Double>();
    public graph() {

        super("Monolithic SingleHelperMode");

        mxGraph graph = new mxGraph();
        Object parent = graph.getDefaultParent();

        graph.getModel().beginUpdate();
        
        
        try {


            // get stylesheet
            mxStylesheet stylesheet = graph.getStylesheet();

            // define stylename
            String styleName = "myImageStyle";
 
           
            // create image style 
                        Hashtable <String, Object> edgeStyle = new Hashtable<String, Object>();
edgeStyle.put(mxConstants.STYLE_SHAPE,    mxConstants.SHAPE_CONNECTOR);
edgeStyle.put(mxConstants.STYLE_ENDARROW, mxConstants.ARROW_CLASSIC);
edgeStyle.put(mxConstants.STYLE_STROKECOLOR, "#000000");
edgeStyle.put(mxConstants.STYLE_FONTCOLOR, "#000000");
stylesheet.setDefaultEdgeStyle(edgeStyle);
 Hashtable <String, Object> vertStyle = new Hashtable<String, Object>();


vertStyle.put(mxConstants.STYLE_FONTCOLOR, "#FF0000");
vertStyle.put(mxConstants.ALIGN_BOTTOM, "#ffffff");
stylesheet.setDefaultVertexStyle(vertStyle);

graph.setStylesheet(stylesheet);

            

        
             vertex.clear();
            
               
            for(int ii=0; ii<nodeNames.size();ii++){
                if(ii==0){
                 
                   vertex.add(graph.insertVertex(parent, null, "Sensor1", nodeLoc.get(ii).X*5 , nodeLoc.get(ii).Y*5, 100, 70, "shape=image;image=/sen.png")); 
                   
                }
                //String e="v"+ii;
               else if(nodeNames.get(ii)=="Fan"){
                vertex.add(graph.insertVertex(parent, null, "Fan", nodeLoc.get(ii).X*5, nodeLoc.get(ii).Y*5, 100, 70, "shape=image;image=/f.png")); } 
                
               else if(nodeNames.get(ii)=="Billboard"){
                vertex.add(graph.insertVertex(parent, null, "Billboard", nodeLoc.get(ii).X*5,nodeLoc.get(ii).Y*5, 100, 70, "shape=image;image=/B.jpg")); } 
                
               else if(nodeNames.get(ii)=="BillBoard2"){
                vertex.add(graph.insertVertex(parent, null, "Billboard2", nodeLoc.get(ii).X*5,nodeLoc.get(ii).Y*5, 100, 70, "shape=image;image=/B.jpg"));} 
                
               else if(nodeNames.get(ii)=="SmartPhone"){
                vertex.add(graph.insertVertex(parent, null, "Smartphone", nodeLoc.get(ii).X*5, nodeLoc.get(ii).Y*5, 100, 70, "shape=image;image=/s.png")); } 
               else if(nodeNames.get(ii)=="Car"){
                vertex.add(graph.insertVertex(parent, null, "Sensor", nodeLoc.get(ii).X*5, nodeLoc.get(ii).Y*5, 100, 70, "shape=image;image=/car.png"));}  
              }
            
        
            
              for(int ii=0; ii<vertex.size();ii++){
                //String e="v"+ii;
                if(ii+1<vertex.size())   {   
             graph.insertEdge(parent, null,comm.get(ii)+" "+integ.get(ii)+"ms", vertex.get(ii), vertex.get(ii+1),"strokeColor=#00FF00;");}
              }
              
          
          

        } finally {
            graph.getModel().endUpdate();
        }

        mxGraphComponent graphComponent = new mxGraphComponent(graph);
        ImageIcon icon = new ImageIcon("bg11.png");
 graphComponent.setBackgroundImage(icon);

        getContentPane().add(graphComponent); 
}}
