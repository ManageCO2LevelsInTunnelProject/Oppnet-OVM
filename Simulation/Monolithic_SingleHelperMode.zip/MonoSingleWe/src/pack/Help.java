/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

/**
 *
 * @author hp
 */

public class Help {

	String helpTextMsg = "Warning: The level of CO2 is high in this area. It’s more than 0.6%.";
	
}
